const form = document.querySelector("#settingsForm");
const portInput = document.querySelector("#port");
const defaultQualitySelect = document.querySelector("#defaultQuality");
const defaultAudioQualitySelect = document.querySelector("#defaultAudioQuality");
const videoQualityRow = document.querySelector("#videoQualityRow");
const audioQualityRow = document.querySelector("#audioQualityRow");
const prefixTypeSelect = document.querySelector("#prefixType");
const customPrefixRow = document.querySelector("#customPrefixRow");
const customPrefixInput = document.querySelector("#customPrefix");
const downloadFolderInput = document.querySelector("#downloadFolder");
const channelsSelect = document.querySelector("#channels");
const markWatchedInput = document.querySelector("#markWatched");
const cookiesBrowserSelect = document.querySelector("#cookiesBrowser");
const result = document.querySelector("#result");

function setResult(text, isError = false) {
  result.textContent = text;
  result.classList.toggle("error", isError);
}

function getSelectedKind() {
  const checked = document.querySelector('input[name="defaultKind"]:checked');
  return checked ? checked.value : "video";
}

function updateQualityRowVisibility() {
  const isAudio = getSelectedKind() === "audio";
  if (videoQualityRow) {
    videoQualityRow.classList.toggle("hidden", isAudio);
  }
  if (audioQualityRow) {
    audioQualityRow.classList.toggle("hidden", !isAudio);
  }
}

function updateCustomPrefixVisibility() {
  if (customPrefixRow && prefixTypeSelect) {
    customPrefixRow.classList.toggle("hidden", prefixTypeSelect.value !== "custom");
  }
}

document.querySelectorAll('input[name="defaultKind"]').forEach((input) => {
  input.addEventListener("change", updateQualityRowVisibility);
});

if (prefixTypeSelect) {
  prefixTypeSelect.addEventListener("change", updateCustomPrefixVisibility);
}

async function save() {
  const port = Number(portInput.value);
  if (!Number.isInteger(port) || port < 1024 || port > 65535) {
    throw new Error("Enter a valid port number (1024-65535).");
  }

  const defaultKind = getSelectedKind();
  const defaultQuality = defaultQualitySelect ? defaultQualitySelect.value || "1080" : "1080";
  const defaultAudioQuality = defaultAudioQualitySelect ? defaultAudioQualitySelect.value || "320" : "320";
  const prefixType = prefixTypeSelect ? prefixTypeSelect.value : "number";
  const customPrefix = customPrefixInput ? customPrefixInput.value.trim() : "";
  const downloadFolder = downloadFolderInput ? downloadFolderInput.value.trim() : "";
  const channels = channelsSelect ? Number(channelsSelect.value) || 8 : 8;
  const markWatched = markWatchedInput ? markWatchedInput.checked : true;
  const cookiesBrowser = cookiesBrowserSelect ? cookiesBrowserSelect.value || "chrome" : "chrome";

  await chrome.storage.local.set({
    port,
    defaultKind,
    defaultQuality,
    defaultAudioQuality,
    prefixType,
    customPrefix,
    downloadFolder,
    channels,
    markWatched,
    cookiesBrowser,
  });
}

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  try {
    await save();
    setResult("Preferences saved successfully.");
  } catch (error) {
    setResult(error.message, true);
  }
});

document.querySelector("#test").addEventListener("click", async () => {
  try {
    await save();
    setResult("Connecting to local service…");
    const health = await OkjaApi.apiRequest("/api/health");
    if (!health.ytDlpAvailable) {
      throw new Error("Connected, but yt-dlp is not available.");
    }
    setResult(`Connected. Downloads save to: ${health.downloadDir}`);
  } catch (error) {
    setResult(error.message, true);
  }
});

OkjaApi.getSettings().then(({ port, defaultKind, defaultQuality, defaultAudioQuality, prefixType, customPrefix, downloadFolder, channels, markWatched, cookiesBrowser }) => {
  portInput.value = port;
  if (defaultQualitySelect) defaultQualitySelect.value = defaultQuality || "1080";
  if (defaultAudioQualitySelect) defaultAudioQualitySelect.value = defaultAudioQuality || "320";
  if (prefixTypeSelect) prefixTypeSelect.value = prefixType || "number";
  if (customPrefixInput) customPrefixInput.value = customPrefix || "";
  if (downloadFolderInput) downloadFolderInput.value = downloadFolder || "";
  if (channelsSelect) channelsSelect.value = String(channels || 8);
  if (markWatchedInput) markWatchedInput.checked = markWatched !== false;
  if (cookiesBrowserSelect) cookiesBrowserSelect.value = cookiesBrowser || "chrome";
  const kindInput = document.querySelector(`input[name="defaultKind"][value="${defaultKind || "video"}"]`);
  if (kindInput) kindInput.checked = true;
  updateQualityRowVisibility();
  updateCustomPrefixVisibility();
});

document.querySelector("#btnOpenSetup")?.addEventListener("click", () => {
  chrome.tabs.create({ url: chrome.runtime.getURL("onboarding.html") });
});

const btnClearCache = document.querySelector("#btnClearCache");
if (btnClearCache) {
  btnClearCache.addEventListener("click", () => {
    btnClearCache.disabled = true;
    setResult("Clearing download cache…");
    chrome.runtime.sendMessage({ type: "clear-cache" }, (res) => {
      btnClearCache.disabled = false;
      if (res?.ok) {
        setResult("Download cache cleared! Previously downloaded videos can now be re-downloaded.");
      } else {
        setResult(res?.error || "Failed to clear cache.", true);
      }
    });
  });
}
