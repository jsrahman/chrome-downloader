importScripts("shared.js");

const YOUTUBE_HOSTS = new Set([
  "youtube.com", "www.youtube.com", "m.youtube.com", "music.youtube.com", "youtu.be",
]);
const NATIVE_HOST = "com.okja.saver";

function isVideoUrl(rawUrl) {
  try {
    const url = new URL(rawUrl);
    return url.protocol === "https:" && YOUTUBE_HOSTS.has(url.hostname.toLowerCase());
  } catch (_error) {
    return false;
  }
}

let trackerTimer = null;
let lastKnownActiveJob = null;
let shutdownTimer = null;
const notifiedJobIds = new Set();

function updateBadge(input) {
  try {
    let count = 0;
    if (typeof input === "number") {
      count = Math.max(0, input);
    } else if (input && typeof input === "object") {
      const queueCount = Number(input.queueCount ?? (Array.isArray(input.queue) ? input.queue.length : 0));
      const activeCount = (input.activeJob && ["downloading", "queued"].includes(input.activeJob.status)) ? 1 : 0;
      count = queueCount + activeCount;
    }

    if (count > 0) {
      chrome.action.setBadgeText({ text: String(count) });
      chrome.action.setBadgeBackgroundColor({ color: "#f59e0b" });
      if (chrome.action.setBadgeTextColor) {
        chrome.action.setBadgeTextColor({ color: "#141816" });
      }
      chrome.action.setTitle({ title: `Okja Saver (${count} in queue)` });
    } else {
      chrome.action.setBadgeText({ text: "" });
      chrome.action.setTitle({ title: "Okja YouTube Saver" });
    }
  } catch (_e) {}
}

async function isServiceAlive() {
  try {
    const { port } = await OkjaApi.getSettings();
    const res = await fetch(OkjaApi.serviceUrl(port, "/api/status"));
    return res.ok;
  } catch (_e) {
    return false;
  }
}

function launchNativeService(port) {
  return new Promise((resolve, reject) => {
    if (!chrome.runtime?.sendNativeMessage) {
      reject(new Error("Native messaging is not supported in this browser environment."));
      return;
    }
    chrome.runtime.sendNativeMessage(
      NATIVE_HOST,
      { action: "start", port },
      (response) => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message || "Failed to launch companion service."));
        } else {
          resolve(response);
        }
      }
    );
  });
}

async function ensureServiceRunning() {
  if (await isServiceAlive()) {
    return true;
  }

  const { port } = await OkjaApi.getSettings();

  try {
    await launchNativeService(port);
  } catch (err) {
    console.warn("Native host start error:", err);
    throw new Error(
      "Download service is not running. Please run ./scripts/install-native-host.sh once to enable auto-start, or ./scripts/start-service.sh."
    );
  }

  // Poll until service is responsive (up to 4 seconds)
  for (let i = 0; i < 40; i++) {
    await new Promise((r) => setTimeout(r, 100));
    if (await isServiceAlive()) {
      return true;
    }
  }

  throw new Error("Download service started but failed to respond on port " + port);
}

async function checkAndUpdateStatus() {
  try {
    const statusData = await OkjaApi.apiRequest("/api/status");
    updateBadge(statusData);
    if ((statusData?.activeJob || (statusData?.queueCount && statusData.queueCount > 0)) && !trackerTimer) {
      startTracking();
    }
    return statusData;
  } catch (_e) {
    updateBadge(null);
    return null;
  }
}

function broadcastToTabs(message) {
  chrome.tabs.query({}, (tabs) => {
    for (const tab of tabs) {
      if (tab.id) {
        chrome.tabs.sendMessage(tab.id, message).catch(() => {});
      }
    }
  });
}

function notifyComplete(job) {
  if (!job || !job.id || notifiedJobIds.has(job.id)) return;
  notifiedJobIds.add(job.id);
  if (notifiedJobIds.size > 200) {
    const oldest = notifiedJobIds.values().next().value;
    notifiedJobIds.delete(oldest);
  }

  const filename = job.filename ? job.filename.split("/").pop() : "";
  const title = job.title || "YouTube video";

  // 1. Native OS notification with explicit ID to prevent duplicate notification cards
  try {
    if (chrome.notifications) {
      chrome.notifications.create(`okja-complete-${job.id}`, {
        type: "basic",
        iconUrl: chrome.runtime.getURL("icon128.png"),
        title: "Okja Saver - Download Complete! ✓",
        message: filename || `${title} saved to download folder.`,
      });
    }
  } catch (_e) {}

  // 2. Broadcast to browser tabs
  broadcastToTabs({
    type: "download-complete",
    job,
    title,
    filename,
  });
}

function startTracking() {
  if (shutdownTimer) {
    clearTimeout(shutdownTimer);
    shutdownTimer = null;
  }
  if (trackerTimer) return;
  trackerTimer = setInterval(async () => {
    try {
      const statusData = await OkjaApi.apiRequest("/api/status");
      const active = statusData?.activeJob;
      updateBadge(statusData);

      if (lastKnownActiveJob && (!active || active.id !== lastKnownActiveJob.id)) {
        // Active job changed or completed
        const prevJob = lastKnownActiveJob;
        lastKnownActiveJob = active;
        try {
          const { job } = await OkjaApi.apiRequest(`/api/downloads/${prevJob.id}`);
          if (job && job.status === "complete") {
            notifyComplete(job);
          }
        } catch (_e) {}
      } else {
        lastKnownActiveJob = active;
      }

      const queueCount = Number(statusData?.queueCount ?? (Array.isArray(statusData?.queue) ? statusData.queue.length : 0));
      if (!active && queueCount === 0) {
        updateBadge(null);
        clearInterval(trackerTimer);
        trackerTimer = null;
      }
    } catch (_e) {
      updateBadge(null);
      clearInterval(trackerTimer);
      trackerTimer = null;
    }
  }, 1200);
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (!message?.type) return;

  if (message.type === "sync-badge") {
    checkAndUpdateStatus()
      .then((data) => sendResponse({ ok: true, data }))
      .catch(() => sendResponse({ ok: false }));
    return true;
  }

  if (message.type === "get-status") {
    OkjaApi.apiRequest("/api/status")
      .then((data) => {
        updateBadge(data);
        sendResponse({ ok: true, data });
      })
      .catch((err) => sendResponse({ ok: false, error: err.message }));
    return true;
  }

  if (message.type === "start-download") {
    if (!isVideoUrl(message.url)) {
      sendResponse({ ok: false, error: "Invalid YouTube URL" });
      return;
    }

    (async () => {
      try {
        const settings = await OkjaApi.getSettings();
        const downloadPayload = {
          url: message.url,
          kind: message.kind || settings.defaultKind || "video",
          quality: message.quality || "best",
          title: message.title || "",
          isPlaylist: Boolean(message.isPlaylist),
          items: Array.isArray(message.items) ? message.items : [],
          prefixType: message.prefixType || settings.prefixType || "number",
          customPrefix: message.customPrefix ?? settings.customPrefix ?? "",
          folder: message.folder ?? settings.downloadFolder ?? "",
          channels: Number(message.channels) || Number(settings.channels) || 8,
          markWatched: message.markWatched !== undefined ? Boolean(message.markWatched) : (settings.markWatched !== false),
          cookiesBrowser: message.cookiesBrowser || settings.cookiesBrowser || "chrome",
        };

        await ensureServiceRunning();
        const data = await OkjaApi.apiRequest("/api/downloads", {
          method: "POST",
          body: JSON.stringify(downloadPayload),
        });
        startTracking();
        checkAndUpdateStatus();
        broadcastToTabs({
          type: "download-started",
          job: data.job,
          queued: data.queued,
          title: message.title || data.job?.title || "",
          originTabId: _sender?.tab?.id ?? null,
        });
        sendResponse({ ok: true, ...data });
      } catch (err) {
        sendResponse({ ok: false, error: err.message });
      }
    })();
    return true;
  }

  if (message.type === "cancel-download") {
    if (!message.jobId) return;
    OkjaApi.apiRequest(`/api/downloads/${message.jobId}`, { method: "DELETE" })
      .then((data) => {
        checkAndUpdateStatus();
        broadcastToTabs({
          type: "download-cancelled",
          jobId: message.jobId,
        });
        sendResponse({ ok: true, ...data });
      })
      .catch((err) => sendResponse({ ok: false, error: err.message }));
    return true;
  }

  if (message.type === "clear-queue") {
    (async () => {
      try {
        if (!(await isServiceAlive())) {
          sendResponse({ ok: true, clearedCount: 0 });
          return;
        }
        const data = await OkjaApi.apiRequest("/api/queue/clear", { method: "POST" });
        checkAndUpdateStatus();
        broadcastToTabs({ type: "queue-cleared" });
        sendResponse({ ok: true, ...data });
      } catch (_err) {
        // If service is offline, queue is already empty
        sendResponse({ ok: true, clearedCount: 0 });
      }
    })();
    return true;
  }

  if (message.type === "stop-all") {
    (async () => {
      lastKnownActiveJob = null;
      updateBadge(null);
      if (trackerTimer) {
        clearInterval(trackerTimer);
        trackerTimer = null;
      }
      broadcastToTabs({ type: "all-stopped" });

      try {
        if (!(await isServiceAlive())) {
          sendResponse({ ok: true, stoppedActive: false, clearedQueue: 0 });
          return;
        }
        const data = await OkjaApi.apiRequest("/api/downloads/stop-all", { method: "POST" });
        checkAndUpdateStatus();
        sendResponse({ ok: true, ...data });
      } catch (_err) {
        // If service is offline, nothing is running
        sendResponse({ ok: true, stoppedActive: false, clearedQueue: 0 });
      }
    })();
    return true;
  }

  if (message.type === "clear-cache") {
    (async () => {
      try {
        if (await isServiceAlive()) {
          await OkjaApi.apiRequest("/api/cache/clear", { method: "POST" });
        }
        sendResponse({ ok: true, message: "Cache cleared" });
      } catch (_err) {
        sendResponse({ ok: true, message: "Cache cleared" });
      }
    })();
    return true;
  }

  if (message.type === "open-onboarding") {
    chrome.tabs.create({ url: chrome.runtime.getURL("onboarding.html") });
    sendResponse({ ok: true });
    return true;
  }

  if (message.type === "open-download" && isVideoUrl(message.url)) {
    (async () => {
      const { onboardingCompleted } = await chrome.storage.local.get("onboardingCompleted");
      if (!onboardingCompleted) {
        chrome.tabs.create({ url: chrome.runtime.getURL("onboarding.html") });
        sendResponse({ ok: false, error: "Setup and verification required." });
        return;
      }
      const title = String(message.title || "").slice(0, 300);
      const launchUrl = new URL(chrome.runtime.getURL("popup.html"));
      launchUrl.searchParams.set("fromShare", "1");
      launchUrl.searchParams.set("url", message.url);
      if (title) launchUrl.searchParams.set("title", title);

      chrome.storage.local.set({
        sharedVideo: { url: message.url, title, createdAt: Date.now() },
      }).then(() => chrome.tabs.create({ url: launchUrl.href }))
        .then(() => sendResponse({ ok: true }))
        .catch((error) => sendResponse({ ok: false, error: error.message }));
    })();
    return true;
  }
});

// Manage dynamic action popup based on package verification state
async function syncActionPopup() {
  try {
    const { onboardingCompleted } = await chrome.storage.local.get("onboardingCompleted");
    if (onboardingCompleted) {
      await chrome.action.setPopup({ popup: "popup.html" });
    } else {
      // Unset popup so clicking the action icon triggers chrome.action.onClicked
      await chrome.action.setPopup({ popup: "" });
    }
  } catch (_e) {}
}

if (chrome.action?.onClicked) {
  chrome.action.onClicked.addListener(async () => {
    const { onboardingCompleted } = await chrome.storage.local.get("onboardingCompleted");
    if (!onboardingCompleted) {
      const onboardingUrl = chrome.runtime.getURL("onboarding.html");
      const tabs = await chrome.tabs.query({ url: onboardingUrl });
      if (tabs.length > 0) {
        chrome.tabs.update(tabs[0].id, { active: true });
        if (tabs[0].windowId) chrome.windows.update(tabs[0].windowId, { focused: true });
      } else {
        chrome.tabs.create({ url: onboardingUrl });
      }
    } else {
      await chrome.action.setPopup({ popup: "popup.html" });
      if (chrome.action.openPopup) {
        try {
          await chrome.action.openPopup();
        } catch (_e) {}
      }
    }
  });
}

// React instantly to verification status and settings changes in storage
chrome.storage?.onChanged?.addListener((changes, area) => {
  if (area === "local") {
    if ("onboardingCompleted" in changes) {
      syncActionPopup();
    }
    const settingsKeys = [
      "defaultKind", "defaultQuality", "defaultAudioQuality",
      "prefixType", "customPrefix", "downloadFolder", "channels",
      "markWatched", "cookiesBrowser", "port",
    ];
    if (settingsKeys.some((k) => k in changes)) {
      OkjaApi.getSettings().then((settings) => {
        broadcastToTabs({ type: "settings-updated", settings });
      }).catch(() => {});
    }
  }
});

// Periodic background check via alarms API to keep badge updated if active
try {
  if (chrome.alarms) {
    chrome.alarms.create("status-badge-sync", { periodInMinutes: 1 });
    chrome.alarms.onAlarm.addListener((alarm) => {
      if (alarm.name === "status-badge-sync") {
        checkAndUpdateStatus();
      }
    });
  }
} catch (_e) {}

checkAndUpdateStatus();
syncActionPopup();
chrome.runtime.onStartup.addListener(() => {
  checkAndUpdateStatus();
  syncActionPopup();
});
chrome.runtime.onInstalled.addListener(async (details) => {
  await checkAndUpdateStatus();
  await syncActionPopup();
  if (details?.reason === "install") {
    chrome.tabs.create({ url: chrome.runtime.getURL("onboarding.html") });
  }
});
